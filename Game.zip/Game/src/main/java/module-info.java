module org.func.game {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;

    opens org.game to javafx.fxml;
    exports org.game;
    exports org.game.physics;
    opens org.game.physics to javafx.fxml;
}