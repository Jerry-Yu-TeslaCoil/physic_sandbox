package org.game;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;

public class MapGame extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MapGame.class.getResource("game-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1730, 926);
        scene.setFill(null);
        stage.setTitle("Yeah!");
        stage.setX(0);
        stage.setY(0);
        stage.setScene(scene);
        stage.initStyle(StageStyle.TRANSPARENT);
        stage.setOnCloseRequest((e)->{
            //e.consume();
            System.exit(0);
        });
        GameController controller = fxmlLoader.getController();
        stage.widthProperty().addListener((e)->{
            controller.width = stage.getWidth();
            controller.sizeSet();
        });
        stage.heightProperty().addListener((e)->{
            controller.height = stage.getHeight();
            controller.sizeSet();
        });
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}