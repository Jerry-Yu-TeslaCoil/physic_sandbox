package org.game;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;
import javafx.util.Duration;
import org.game.physics.Force;
import org.game.physics.Link;
import org.game.physics.Particle;
import org.game.physics.model.Sphere;

import java.util.*;

public class GameController {
    private final ArrayList<Particle> particleList = new ArrayList<>();
    private final ArrayList<Particle> addList = new ArrayList<>();

    public double fPS = 180;
    public AnchorPane pane;
    double senseDist = 200;
    double forceIntensity = 0.02;
    double mouseX, mouseY, angle;
    int dotLinkNum = 1;
    int dotNum = 30;

    public double width, height;

    @FXML
    public Canvas canvas;

    GraphicsContext gc;

    int ticker = 0;

    @FXML
    public void initialize() {
        pane.setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 0, 0.02), CornerRadii.EMPTY, Insets.EMPTY)));
        double sPF = 1 / fPS;
        gc = canvas.getGraphicsContext2D();
        gc.setStroke(Color.rgb(255, 145, 0));
        gc.setFill(Color.rgb(255, 145, 0));
        gc.setLineWidth(2);
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(sPF), actionEvent -> {
            flash();
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    public void flash() {
        ticker++;
        particleList.addAll(0, addList);
        addList.clear();

        for (Particle particle : particleList) {
            if (particle.getX() < 0) {
                particle.getMomentaryForce().add(new Force(10, 5 * -Math.signum(particle.getDY())));
            }
            if (particle.getX() > canvas.getWidth()) {
                particle.getMomentaryForce().add(new Force(-10, 5 * -Math.signum(particle.getDY())));
            }
            if (particle.getY() < 0) {
                particle.getMomentaryForce().add(new Force(5 * -Math.signum(particle.getDX()), 10));
            }
            if (particle.getY() > canvas.getHeight()) {
                particle.getMomentaryForce().add(new Force(5 * -Math.signum(particle.getDX()), -10));
            }
        }
        if (ticker % 3 == 0) {
            gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        }
        Force[] forces = new Force[particleList.size()];
        for (int i = 0; i < particleList.size(); i++) {
            forces[i] = new Force(0, 0);
        }

        for (int j = 0, dotListSize = particleList.size(); j < dotListSize; j++) {
            Particle particle = particleList.get(j);
            Force force = new Force(0, 0);
            force = force.add(forces[j]);
            if (j == 0 && Math.abs(particle.getX() - mouseX) < senseDist
                    && Math.abs(particle.getY() - mouseY) < senseDist) {
                force = force.add(new Force(mouseX - particle.getX(), mouseY - particle.getY()).mul(0.01));
            }
            particle.addMomentaryForce(force.mul(forceIntensity));
            particle.flash();

            if (ticker % 3 == 0) {
                gc.fillArc(particle.getX() - 3, particle.getY() - 3, 6, 6, 0, 360, ArcType.ROUND);


                ArrayList<Link> links = particle.getLinkList();
                for (Link link : links) {
                    Particle[] particles = link.getParticles();
                    gc.strokeLine(particles[0].getX(),
                            particles[0].getY(),
                            particles[1].getX(),
                            particles[1].getY());
                }
            }
        }
        if (ticker > 3) {
            ticker = 0;
        }
    }

    public void moved(MouseEvent mouseEvent) {
        double moveDX = mouseEvent.getSceneX() - mouseX;
        double moveDY = mouseEvent.getSceneY() - mouseY;
        angle = Math.atan2(moveDY, moveDX);
        this.mouseX = mouseEvent.getSceneX();
        this.mouseY = mouseEvent.getSceneY();
    }

    public void clicked(MouseEvent mouseEvent) {
        if (mouseEvent.getButton() == MouseButton.PRIMARY) {
            Random random = new Random();
            int mass = random.nextInt(1, 5);
            Particle particle;
            particle = new Particle(mouseX, mouseY,
                    0,
                    0, mass);
            //Gravity
            particle.addConstantForce(new Force(0, 10 * mass).mul(forceIntensity));
            particle.setResistantCoefficient(0.001);
            addList.add(0, particle);
            if (addList.size() > 1) {
                new Link(new Particle[]{particle, addList.get(1)}, 30, 0.001);
            }
        } else {
            Sphere sphere = new Sphere(100, mouseX, mouseY, 35, 0.01);
            for (Particle particle : sphere) {
                particle.setResistantCoefficient(0.01);
                particle.addConstantForce(new Force(0, 2).mul(forceIntensity));
            }
            addList.addAll(sphere);
        }
    }

    public void sizeSet() {
        pane.setPrefWidth(this.width);
        pane.setPrefHeight(this.height);
        canvas.setWidth(this.width);
        canvas.setHeight(this.height);
    }
}