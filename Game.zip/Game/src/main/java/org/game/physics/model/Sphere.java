package org.game.physics.model;

import org.game.physics.Link;
import org.game.physics.Particle;

import java.util.ArrayList;

public class Sphere extends ArrayList<Particle> implements Model {
    public final double radius;
    private double centerX, centerY;

    public Sphere(double radius, double x, double y, double mass, double elasticIntensity) {
        elasticIntensity *= 1.5;
        this.radius = radius;
        double intensity = 1;
        double outerDist = radius * Math.PI / 5 * intensity;
        for (int i = 0; i < 360; i += 36) {
            Particle p = new Particle(x + radius * Math.cos(Math.toRadians(i)),
                    y + radius * Math.sin(Math.toRadians(i)), 0, 0, mass / 10);
            if (i != 0) {
                new Link(new Particle[]{p, this.get(i / 36 - 1)}, outerDist, elasticIntensity);
            }
            this.add(p);
        }
        new Link(new Particle[]{this.get(0), this.get(9)}, outerDist, elasticIntensity);
        /**/
        for (int i = 0; i < 5; i++) {
            new Link(new Particle[]{this.get(i), this.get(i + 5)}, radius * 8 * intensity, elasticIntensity);
        }

        for (int i = 0; i < 10; i++) {
            new Link(new Particle[]{this.get(i), this.get((i + 2) % 10)}, radius * 1 * intensity, elasticIntensity);
        }
        for (int i = 0; i < 10; i++) {
            new Link(new Particle[]{this.get(i), this.get((i + 3) % 10)}, radius * 2 * intensity, elasticIntensity);
        }
    }

    @Override
    public void flash() {

    }
}
