package org.game.physics;

public class Force {
    private double fX;
    private double fY;
    private Particle object;

    public Force(double fX, double fY) {
        this.fX = fX;
        this.fY = fY;
    }

    public double getFX() {
        return fX;
    }

    public void setFX(double fX) {
        this.fX = fX;
    }

    public double getFY() {
        return fY;
    }

    public void setFY(double fY) {
        this.fY = fY;
    }

    public Force getNegative() {
        return new Force(-fX, -fY);
    }

    public Force add(Force f) {
        return new Force(fX + f.getFX(), fY + f.getFY());
    }

    public Force mul(double lambda) {
        return new Force(fX * lambda, fY * lambda);
    }

    public double mul(Force f) {
        return fX * f.fX + fY * f.fY;
    }

    public Force normalize() {
        return new Force(fX, fY).mul(1.0 / Math.sqrt(fX * fX + fY * fY));
    }

    public Particle getObject() {
        return object;
    }

    public void setObject(Particle object) {
        this.object = object;
    }

    @Override
    public String toString() {
        return "Force [fX=" + fX + ", fY=" + fY + "]";
    }
}
