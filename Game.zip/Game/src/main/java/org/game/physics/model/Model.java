package org.game.physics.model;

public interface Model {
    void flash();
}
