package org.game.physics;

public class Link {
    private final Particle[] particles;
    private double length;
    private double elasticCoefficient;

    public Link(Particle[] particles, double length, double elasticCoefficient) {
        this.particles = new Particle[2];
        this.particles[0] = particles[0];
        this.particles[1] = particles[1];
        particles[0].getLinkList().add(this);
        particles[1].getLinkList().add(this);
        this.length = length;
        this.elasticCoefficient = elasticCoefficient;
    }

    public Force getForce(Particle p) {
        double dX = particles[0].getX() - particles[1].getX();
        double dY = particles[0].getY() - particles[1].getY();
        Force force = new Force(dX, dY).normalize();
        double r = Math.sqrt(dX * dX + dY * dY);
        if (particles[0] == p) {
            force = force.getNegative();
        }
        force = force.mul(r - length * 0.5).mul(elasticCoefficient);
        return force;
    }

    public void cut(Particle p) {
        if (particles[0] == p) {
            particles[1].getLinkList().remove(this);
            return;
        }
        particles[0].getLinkList().remove(this);
    }

    public void setParticles(Particle[] particles) {
        this.particles[0] = particles[0];
        this.particles[1] = particles[1];
    }

    public Particle[] getParticles() {
        return particles;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getElasticCoefficient() {
        return elasticCoefficient;
    }

    public void setElasticCoefficient(double elasticCoefficient) {
        this.elasticCoefficient = elasticCoefficient;
    }
}
