package org.game.physics;

import org.game.physics.Link;

import java.util.ArrayList;

public class Particle {
    private double x;
    private double y;
    private double dX;
    private double dY;
    private double mass;
    private double resistantCoefficient;

    private final ArrayList<Force> constantForce;
    private final ArrayList<Force> momentaryForce;
    private final ArrayList<Link> linkList;

    public Particle(double x, double y, double dX, double dY, double mass) {
        this.x = x;
        this.y = y;
        this.dX = dX;
        this.dY = dY;
        this.mass = mass;
        this.resistantCoefficient = 1;
        constantForce = new ArrayList<>();
        momentaryForce = new ArrayList<>();
        linkList = new ArrayList<>();
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getDX() {
        return dX;
    }

    public void setDX(double dX) {
        this.dX = dX;
    }

    public double getDY() {
        return dY;
    }

    public void setDY(double dY) {
        this.dY = dY;
    }

    public void flash() {
        Force force = new Force(0, 0);
        force = force.add(getResistanceForce());
        for (Link link : linkList) {
            force = force.add(link.getForce(this));
        }
        for (Force cForce : constantForce) {
            force = force.add(cForce);
        }
        for (Force mForce : momentaryForce) {
            force = force.add(mForce);
        }
        momentaryForce.clear();
        //System.out.println(this + " flashed " + force);
        this.dX += force.getFX() / mass;
        this.dY += force.getFY() / mass;
        this.x += this.dX;
        this.y += this.dY;
    }

    public double getMass() {
        return mass;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }

    public void addConstantForce(Force force) {
        force.setObject(this);
        constantForce.add(force);
    }

    public ArrayList<Force> getConstantForce() {
        return constantForce;
    }

    public void addMomentaryForce(Force force) {
        force.setObject(this);
        momentaryForce.add(force);
    }

    public ArrayList<Force> getMomentaryForce() {
        return momentaryForce;
    }

    public double getResistantCoefficient() {
        return resistantCoefficient;
    }

    public void setResistantCoefficient(double resistantCoefficient) {
        this.resistantCoefficient = resistantCoefficient;
    }

    private Force getResistanceForce() {
        double fX = -dX * dX * Math.signum(dX);
        double fY = -dY * dY * Math.signum(dY);
        return new Force(fX, fY).mul(resistantCoefficient);
    }

    @Override
    public String toString() {
        return "Particle at [" + x + ", " + y + ", " + dX + ", " + dY + "]";
    }

    public ArrayList<Link> getLinkList() {
        return linkList;
    }
}
